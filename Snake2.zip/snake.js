﻿function Startpositionsnake(obj) {
    obj.style.top = 0 + "px";
    obj.style.left = 0 + "px";
}
function Startpositionfood(obj) {
    obj.style.top = Math.random() * gamespace.clientHeight + "px";
    obj.style.left = Math.random() * gamespace.clientWidth + "px";
}
function MoveSnake() {
    var gamesound = document.getElementById("gamesound");
    gamesound.play();
    var gameover = document.getElementById("eataudio");
    var mx;
    mx = parseInt(snake1.style.left) + xInc;
    if (mx < 0 || mx > gamespace.clientWidth - snake.clientWidth) {

        window.clearInterval(interval);
        gamesound.pause();
        gameover.play();
        Highscore()
    } else {
        snake1.style.left = mx + "px";
    }
    var my;
    my = parseInt(snake1.style.top) + yInc;
    if (my < 0 || my > gamespace.clientHeight - snake.clientHeight) {

        window.clearInterval(interval);
        gamesound.pause();
        gameover.play();
        Highscore()
    } else {
        snake1.style.top = my + "px";
    }
}
function Collision(obj1, obj2) {
    var snake0 = obj1.getBoundingClientRect();
    var food0 = obj2.getBoundingClientRect();
    var eat = document.getElementById("eataudio"); 
    if (snake0.left < food0.left + food0.width && snake0.left + snake0.width > food0.left &&
        snake0.top < food0.top + food0.height && snake0.top + snake0.height > food0.top) {

        food1.style.top = Math.random() * gamespace.clientHeight + "px";
        food1.style.left = Math.random() * gamespace.clientWidth + "px";

        score = score + 1;
        parScore.innerText = "Score: " + score;
        eat.play();
    }
}
function Highscore() {
    
    window.location.href = "Scoreboard.aspx?currentscore=" + score;
}