﻿var x;
function btnEasonclick() {
    x = 100
    window.location.href = "Start.html?currentsetting=" + x;
}
function btnMedonclick() {
    x = 20
    window.location.href = "Start.html?currentsetting=" + x;
}
function btnHaronclick() {
    x = 5
    window.location.href = "Start.html?currentsetting=" + x;
}
function btnBackonclick() {
    window.location = "Homepage.aspx";
}